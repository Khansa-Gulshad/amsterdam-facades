
#  potential-vertical-green-spaces
## Aims and Objectives
Nature-Based Solutions are able to provide natural, multifaceted solutions to problems many cities around the world face. Since urban space is scarce, potential vertical spaces (facades and roofs) have to be considered for greening. This project aims to find potential vertical spaces in dense urban areas that are suitable to be greened, using deep learning and geospatial analysis.

## The Project
The project contains two Jupyter Notebooks that can be run seperately.

 - `Facades.ipynb` estimates the greening potential on building facades using image segmentation. The output is a geopackage of sample points containing a facade Greening Potential Score (GPS).
 ![*Facade Greening Potential Estimation Steps*](https://github.com/Spatial-Data-Science-and-GEO-AI-Lab/potential-vertical-green-spaces/blob/main/images/Workflow_Facades.png)
 
 - `Roofs.ipynb` estimates the greening potential on rooftops using geospatial analysis. The output is a geopackage of all suitable buildings (filtered) and all buildings (unfiltered) containing the roof GPS. 
 *Note: as of this moment, the study area is limited to Amsterdam only.*
![*Roof Greening Potential Estimation Steps*](https://github.com/Spatial-Data-Science-and-GEO-AI-Lab/potential-vertical-green-spaces/blob/main/images/Workflow_Roofs.png)
 
## Setup
To run the project in Google Colab, clone the complete project to your Google Drive folder (e.g. `/My Drive/MyFolderName`). Then, open one of the Jupyter Notebooks in Google Colab. Written instructions are also included within each notebook that explain each step of the process. 
It is recommended that for hardware acceleration a GPU is set and high RAM usage is turned on. To change this in Google Colab, go to `Runtime > Change runtime type > Hardware accelerator` to select a GPU (V100 GPU recommended) and turn on high RAM usage.

### Facades.ipynb

#### Requirements
`Facades.ipynb` uses the following dependencies:

    Pillow==10.0.1
    segment-geospatial==0.10.2
    groundingdino-py==0.4.0
    leafmap==0.31.2
    localtileserver==0.10.1
    geopandas==0.13.2
    ipython==7.34.0
    mercantile==1.2.1
    networkx==3.2.1
    numpy==1.25.2
    osmnx==1.9.1
    pandas==1.5.3
    Requests==2.31.0
    scipy==1.11.4
    Shapely==2.0.2
    tqdm==4.66.2
    vt2geojson==0.2.1
    area==1.1.1

#### Instructions
 **1.** Open `Facades.ipynb` and make sure to set your working directory to your installed Google Drive path. Also make sure that `work_on_drive` is set to `True`.

	working_dir = '/My Drive/MyFolderName'
	work_on_drive = True
   **2.** Specify the desired input parameters.

    city_name = 'Diamantbuurt, Amsterdam'
    
    access_token = 'MLY|XXXXXXXX|xxxxxxxxxxxxxxxx'
    distance = 50
    num_sample_images = float('inf')
    begin = None
    end = None
    save_roads_points = True
    save_streetview = False
   - **city_name**
 The (neighborhood of the) city to analyze. When a named area processing is chosen (step 3), the OpenStreetMap boundary of the (neighborhood of the) city is used. When bounding box processing is used, this is only used to name the output folders.
 - **access_token**
 The Mapillary street view access token.
 - **distance**
 Distance between sample points in meters.
 - **num_sample_images**
 Maximum number of sample points per processing area (bounding box or named area). For a bounding box selection, the area may be split into smaller processing areas. For named areas, this is the total number of sample points.
 - **begin**
 First index of a smaller analysis range of the sample points per processing area.
 - **end**
 Last index of a smaller analysis range of the sample points per processing area.
 - **save_roads_points**
 Choose whether to save the temporary road network and sample points data.
 - **save_streetview**
 Choose whether to download the analyzed street view images.

**3.** **Optional**: specify an area selection using a bounding box. To use this option, simply draw a rectangular polygon on the provided Leafmap insert and continue as usual. When no rectangle is drawn, the place name is used as the selected study area.

**4.** These inputs are used to calculate the facade GPS for the facades in the study area. The runtime may vary based on the size of the study area.

**5.** When done, a `city_name_features.gpkg` geopackage is automatically created inside `/results/city_name/` which contains the analyzed sample points and the facade GPS found at these points.

### Roofs.ipynb

#### Requirements
`Roofs.ipynb` uses the following dependencies:

    pypdl==1.3.0
    rasterio==1.3.9
    localtileserver==0.10.1
    rasterstats==0.19.0
#### Instructions
 **1.** Open `Roofs.ipynb` and make sure to set your working directory to your desired Google Drive path. Also make sure that `work_on_drive` is set to `True`.

	    working_dir = '/My Drive/MyFolderName'
	    work_on_drive = True
   **2.** The notebook automatically downloads the required buiding dataset (BAG), Digital Surface Model (DSM) tiles, Digital Terrain Model (DTM) tiles, and municipal boundaries if they are missing. These may also be added manually.
   
   **3.** These inputs are used to calculate the height, slope, area, and age of each building in the study area. Unsuitable buildings are filtered out. For the remaining buildings, a roof GPS is calculated.
   
   **4.** When done, `filtered_BAG_Amsterdam.gpkg` and `unfiltered_BAG_Amsterdam.gpkg` are automatically created inside `/roofs/` which contains the roof GPS for the potential suitable buildings (filtered) and all buildings (unfiltered).
   
## Acknowledgements
This project was made by F.E. Peranović as part of the thesis for the master Geographical Information Management and Applications (GIMA) at Utrecht University, under supervision of Dr. S.M. Labib.
