import csv
import os
import rasterio

# Creates a folder in "roofs" path if it doesn't exist yet
def prepare_folder_roofs(folder_name):
  dir_path = os.path.join("roofs", folder_name)
  if not os.path.exists(dir_path):
      os.makedirs(dir_path)


# Prepares roof folder structure
def prepare_roof_folders():
  folders = ["DSM_tiles", 
             "DTM_tiles", 
             "DSM_merged", 
             "DTM_merged", 
             "BAG",
             "Boundaries"]

  for folder in folders:
    prepare_folder_roofs(folder)


# Downloads DSM and DTM tiles using text files specifying the download paths
def download_DSM_DTM_tiles(dl, DSM_info_path, DTM_info_path):
  # Download DSM tiles
  with open(DSM_info_path, 'r') as f:
    reader = csv.reader(f, delimiter='\t')

    for row in reader:
      file_name = row[0]
      coordinates = row[1]

      print(file_name, coordinates)
      DSM_tile_name = f"Amsterdam_DSM_{file_name}.tif"

      # Download the missing DSM tiles
      if DSM_tile_name in os.listdir(os.path.join("roofs", "DSM_tiles")):
        print(f"{DSM_tile_name} already exists!\n")
      else:
        print(f"Downloading {file_name} ...")

        output_path = os.path.join("roofs", "DSM_tiles", DSM_tile_name)
        download_url = f"https://service.pdok.nl/rws/ahn/atom/downloads/dsm_05m/{file_name}.tif"
        dl.start(download_url, output_path)

  print("Finished downloading DSM tiles. Now starting DTM tile download\n")

  # Download DTM tiles
  with open(DTM_info_path, 'r') as f:
    reader = csv.reader(f, delimiter='\t')

    for row in reader:
      file_name = row[0]
      coordinates = row[1]

      print(file_name, coordinates)
      DTM_tile_name = f"Amsterdam_DTM_{file_name}.tif"

      # Download the missing DTM tiles
      if DTM_tile_name in os.listdir(os.path.join("roofs", "DTM_tiles")):
        print(f"{DTM_tile_name} already exists!\n")
      else:
        print(f"Downloading {file_name} ...")

        output_path = os.path.join("roofs", "DTM_tiles", DTM_tile_name)
        download_url = f"https://service.pdok.nl/rws/ahn/atom/downloads/dtm_05m/{file_name}.tif"
        dl.start(download_url, output_path)

  print("Finished downloading DSM tiles.")
  

# Function adapted from ondrejmlynarc
# https://github.com/Spatial-Data-Science-and-GEO-AI-Lab/2.5D-GreenViewIndex-Netherlands/blob/main/Data%20collection/data_extraction.py
# Merges TIF files inside a directory. The output is a merged TIF mosaic.
def merge_tif_files(extracted_dir, output_file):
  # Get all TIF files
  tif_files = []
  for root, dirs, files in os.walk(extracted_dir):
      tif_files += [os.path.join(root, file) for file in files if file.endswith('.tif') or file.endswith('.TIF')]

  if not tif_files:
      print("No valid TIF files found in the extracted directory.")
      return

  src_files = [rasterio.open(tif_file) for tif_file in tif_files]

  # Merge them into a mosaic
  merged, out_trans = rasterio.merge.merge(src_files)

  meta = src_files[0].meta
  meta.update({
      "driver": "GTiff",
      "height": merged.shape[1],
      "width": merged.shape[2],
      "transform": out_trans
  })

  # Save the output
  with rasterio.open(output_file, "w", **meta) as dst:
      dst.write(merged)

  for src_file in src_files:
      src_file.close()


# Takes a dataframe column and normalizes it to a 0-1 range
def normalize_df_column(df, column_name, norm_column_name, invert=False):
  # Change column dtype to float if necessary
  if df[column_name].dtype == object:
    print(f"Changed {column_name} column to float dtype")
    df[column_name] = df[column_name].astype(float)

  # Calculate min and max values of the whole column
  min_val = min(x for x in df[column_name] if x is not None)
  max_val = max(x for x in df[column_name] if x is not None)

  # Use min-max scaling to a range of 0-1
  if invert == False:
    df[norm_column_name] = (df[column_name] - min_val) / (max_val - min_val)
  # In cases where lower values are better, invert the normalization
  else:
    df[norm_column_name] = 1 - (df[column_name] - min_val) / (max_val - min_val)

  return